(function(){
  const D=window.SITE_DATA;
  const byId=id=>document.getElementById(id);
  const prefixFor=active=>active==='team'?'../../':'./';

  window.toggleMenu=function(){
    const n=byId('navLinks');
    if(n)n.classList.toggle('open');
  };

  function nav(active){
    const p=prefixFor(active);
    return `<header class="nav">
      <div class="container nav-inner">
        <a class="brand" href="${p}index.html">
          <div class="brand-mark">СМО</div>
          <div class="brand-copy"><b>${D.site.shortTitle}</b><span>${D.site.direction}</span></div>
        </a>
        <button class="nav-toggle" type="button" onclick="toggleMenu()">Меню</button>
        <nav id="navLinks" class="nav-links">
          <a href="${p}index.html">Главная</a>
          <a href="${p}about.html">О нас</a>
          <a href="${p}teams.html">Наши отряды</a>
          <a href="${p}contacts.html">Контакты</a>
          <a href="${p}join.html">Вступить</a>
          <a class="cabinet" href="${D.site.cabinetUrl}" target="_blank" rel="noopener">Личный кабинет</a>
        </nav>
      </div>
    </header>`;
  }

  function footer(active){
    const p=prefixFor(active);
    return `<footer class="footer">
      <div class="container footer-grid">
        <div>
          <strong>${D.site.title}</strong>
          <p>${D.site.direction}</p>
          <small>© ${new Date().getFullYear()} ШСО Астраханского ГМУ</small>
        </div>
        <div class="footer-links">
          <a href="${p}about.html">О нас</a>
          <a href="${p}teams.html">Отряды</a>
          <a href="${p}join.html">Вступить</a>
          <a href="${D.site.vkUrl}" target="_blank" rel="noopener">ВКонтакте</a>
          <a href="${D.site.cabinetUrl}" target="_blank" rel="noopener">Личный кабинет</a>
        </div>
      </div>
    </footer>`;
  }

  window.renderShell=function(active){
    byId('nav').innerHTML=nav(active);
    byId('footer').innerHTML=footer(active);
  };

  window.renderStats=function(target,stats){
    byId(target).innerHTML=stats.map(s=>`<div class="stat"><strong>${s.value}</strong><span>${s.label}</span></div>`).join('');
  };

  window.renderTeams=function(target){
    byId(target).innerHTML=D.teams.map((t,i)=>`
      <a class="team-card" style="--accent:${t.accent}" href="./teams/${t.slug}/">
        <span class="num">0${i+1}</span>
        <div><h3>${t.name}</h3><p>${t.description}</p></div>
        <span class="open">Открыть отряд →</span>
      </a>`).join('');
  };

  window.renderStaff=function(target,staff,pathPrefix=''){
    const fallback=pathPrefix+'assets/person-placeholder.svg';
    byId(target).innerHTML=staff.map(p=>`
      <article class="person">
        <img src="${pathPrefix}${p.photo||'assets/person-placeholder.svg'}" alt="${p.name}" loading="lazy"
             onerror="this.onerror=null;this.src='${fallback}'">
        <div class="person-body">
          <strong>${p.name}</strong><span>${p.role}</span>
          ${p.vk?`<a class="person-link" href="${p.vk}" target="_blank" rel="noopener">ВКонтакте →</a>`:''}
        </div>
      </article>`).join('');
  };

  window.applyHeroImage=function(){
    const hero=document.querySelector('.hero-photo-placeholder');
    if(!hero)return;
    hero.style.backgroundImage=`linear-gradient(180deg,rgba(16,24,40,.10),rgba(16,24,40,.58)),url('${D.site.heroImage}')`;
  };

  window.submitJoin=async function(e){
    e.preventDefault();
    const form=e.target;
    const btn=form.querySelector('button[type=submit]');
    const note=form.querySelector('.form-status');
    const data=Object.fromEntries(new FormData(form).entries());
    data.createdAt=new Date().toISOString();
    btn.disabled=true; btn.textContent='Отправляем…';
    if(note) note.textContent='';
    try{
      if(!D.site.joinEndpoint){
        throw new Error('Анкета ещё не подключена к Google Таблице. Администратору нужно указать joinEndpoint в data.js.');
      }
      const res=await fetch(D.site.joinEndpoint,{
        method:'POST',
        headers:{'Content-Type':'text/plain;charset=utf-8'},
        body:JSON.stringify(data)
      });
      if(!res.ok) throw new Error('Сервер вернул ошибку '+res.status);
      if(note){note.className='form-status success';note.textContent='Анкета отправлена. Комсостав свяжется с тобой.';}
      form.reset();
    }catch(err){
      if(note){note.className='form-status error';note.textContent=err.message||'Не удалось отправить анкету.';}
    }finally{
      btn.disabled=false; btn.textContent='Отправить анкету';
    }
  };

  window.renderVideo=function(){
    const box=byId('videoArea');
    if(!box)return;
    if(D.site.videoUrl){
      box.innerHTML=`<div class="video-embed"><iframe src="${D.site.videoUrl}" allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowfullscreen title="Видео о штабе"></iframe></div>`;
    }
  };

  window.renderTeamPage=function(slug){
    const t=D.teams.find(x=>x.slug===slug);
    if(!t)return;
    document.documentElement.style.setProperty('--team-accent',t.accent);
    const hero=byId('teamHero');
    hero.style.backgroundImage=`linear-gradient(90deg,rgba(16,24,40,.94),rgba(16,24,40,.66)),url('../../${t.heroImage}')`;
    hero.innerHTML=`<div class="container">
      <div class="team-kicker" style="color:${t.accent}">${t.tagline}</div>
      <h1>${t.name}</h1>
      <p>${t.description}</p>
      <div class="actions">
        <a class="btn btn-primary" href="../../join.html?team=${encodeURIComponent(t.name)}">Хочу вступить</a>
        <a class="btn btn-secondary" href="../../teams.html">Все отряды</a>
      </div>
    </div>`;
    renderStats('teamStats',t.stats);
    byId('achievements').innerHTML=t.achievements.length
      ? t.achievements.map(a=>`<div class="achievement">${a}</div>`).join('')
      : `<div class="empty-note">Раздел достижений будет дополняться.</div>`;
    renderStaff('command',t.command.map(x=>({...x,photo:'assets/person-placeholder.svg'})),'../../');
    const social=byId('teamSocial');
    if(social){
      social.innerHTML=t.social&&t.social.length
        ? t.social.map(s=>`<a class="btn btn-secondary" href="${s.url}" target="_blank" rel="noopener">${s.label}</a>`).join('')
        : `<span class="muted">Ссылки на социальные сети добавим позже.</span>`;
    }
  };

  window.prefillJoinTeam=function(){
    const q=new URLSearchParams(location.search).get('team');
    if(!q)return;
    const sel=document.querySelector('select[name=team]');
    if(sel) sel.value=q;
  };
})();